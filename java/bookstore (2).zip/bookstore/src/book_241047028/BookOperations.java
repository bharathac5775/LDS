package book_241047028;

public interface BookOperations {
    void addbook(Book book);
    void deletebook(String bookid);
    void display();
}
