package reg_241047037;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class Dbconnection {
    private static final Logger logger = LogManager.getLogger(Dbconnection.class);


    private static Connection connection;

    static {
        try {
            Properties props = new Properties();

            // Load db.properties as a resource
            try (InputStream inputStream = Dbconnection.class.getClassLoader().getResourceAsStream("reg_241047037/db.properties")) {
                if (inputStream == null) {
                    throw new IllegalArgumentException("db.properties not found in the classpath");
                }
                props.load(inputStream);
            }














            String url = props.getProperty("db.url");
            String username = props.getProperty("db.username");
            String password = props.getProperty("db.password");

            connection = DriverManager.getConnection(url, username, password);
            logger.info("Database connection established.");
        } catch (SQLException | IOException e) {
            logger.error("Error initializing DB connection", e);
        }
    }

    public static Connection getConnection() {
        return connection;
    }
}
