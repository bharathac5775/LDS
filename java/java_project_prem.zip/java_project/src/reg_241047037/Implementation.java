package reg_241047037;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Implementation implements Interface {
    private static final Logger logger = LogManager.getLogger(Implementation.class);
    private Connection connection;

    public Implementation() {
        this.connection = Dbconnection.getConnection();
        createDatabaseAndTables();
    }

    private void createDatabaseAndTables() {
        try (Statement stmt = connection.createStatement()) {
            stmt.execute("IF DB_ID('pre_241047037') IS NULL CREATE DATABASE pre_241047037;");
            stmt.execute("USE pre_241047037;");
            stmt.execute("""
                    IF OBJECT_ID('Students', 'U') IS NULL
                    CREATE TABLE Students (
                        id INT PRIMARY KEY IDENTITY(1,1),
                        rollNumber INT NOT NULL UNIQUE,
                        name NVARCHAR(100),
                        dob NVARCHAR(10),
                        age INT
                    );
                    """);

















            stmt.execute("""
                    IF OBJECT_ID('Subjects', 'U') IS NULL
                    CREATE TABLE Subjects (
                        id INT PRIMARY KEY IDENTITY(1,1),
                        subjectName NVARCHAR(100) NOT NULL UNIQUE
                    );
                    """);
            stmt.execute("""
                    IF OBJECT_ID('StudentSubjects', 'U') IS NULL
                    CREATE TABLE StudentSubjects (
                        studentId INT,
                        subjectId INT,
                        PRIMARY KEY (studentId, subjectId),
                        FOREIGN KEY (studentId) REFERENCES Students(id),
                        FOREIGN KEY (subjectId) REFERENCES Subjects(id)
                    );
                    """);
            logger.info("Database and tables ensured.");
        } catch (SQLException e) {
            logger.error("Error creating database/tables", e);
        }
    }



    @Override
    public void addStudent(Student student) {
        try {
            connection.setAutoCommit(false); // Start transaction

            // Add student to the Students table
            PreparedStatement pstmt = connection.prepareStatement(
                    "INSERT INTO Students (rollNumber, name, dob, age) VALUES (?, ?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            pstmt.setInt(1, student.getRollNumber());
            pstmt.setString(2, student.getName());
            pstmt.setString(3, student.getDob());
            pstmt.setInt(4, student.getAge());
            pstmt.executeUpdate();

            // Retrieve generated student ID
            ResultSet rs = pstmt.getGeneratedKeys();
            rs.next();
            int studentId = rs.getInt(1);

            // Prompt for subject names
            System.out.println("Enter Subject Names for the student (comma-separated): ");
            String subjectNamesInput = new java.util.Scanner(System.in).nextLine();
            String[] subjectNames = subjectNamesInput.split(",");

            for (String subjectName : subjectNames) {
                subjectName = subjectName.trim();

                // Check if the subject exists
                int subjectId = getOrAddSubject(subjectName);

                // Add association between student and subject
                PreparedStatement ssPstmt = connection.prepareStatement(
                        "INSERT INTO StudentSubjects (studentId, subjectId) VALUES (?, ?)");
                ssPstmt.setInt(1, studentId);
                ssPstmt.setInt(2, subjectId);
                ssPstmt.executeUpdate();
            }

            connection.commit(); // Commit transaction
            logger.info("Added student with subjects: " + student);
        } catch (SQLException e) {
            try {
                connection.rollback(); // Rollback transaction in case of error
            } catch (SQLException rollbackEx) {
                logger.error("Error rolling back transaction", rollbackEx);
            }
            logger.error("Error adding student", e);
        } finally {
            try {
                connection.setAutoCommit(true); // Reset auto-commit mode
            } catch (SQLException autoCommitEx) {
                logger.error("Error resetting auto-commit", autoCommitEx);
            }
        }
    }

    @Override
    public void addSubject(Subject subject) {
        try (PreparedStatement pstmt = connection.prepareStatement(
                "INSERT INTO Subjects (subjectName) VALUES (?)")) {
            pstmt.setString(1, subject.getSubjectName());
            pstmt.executeUpdate();
            logger.info("Added subject: " + subject);
        } catch (SQLException e) {
            logger.error("Error adding subject", e);
        }
    }

    @Override
    public List<Student> getAllStudents() {
        List<Student> students = new ArrayList<>();
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM Students")) {
            while (rs.next()) {
                students.add(new Student(
                        rs.getInt("id"),
                        rs.getInt("rollNumber"),
                        rs.getString("name"),
                        rs.getString("dob"),
                        rs.getInt("age")));
            }
        } catch (SQLException e) {
            logger.error("Error retrieving students", e);
        }
        return students;
    }

    @Override
    public List<Subject> getAllSubjects() {
        List<Subject> subjects = new ArrayList<>();
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM Subjects")) {
            while (rs.next()) {
                subjects.add(new Subject(
                        rs.getInt("id"),
                        rs.getString("subjectName")));
            }
        } catch (SQLException e) {
            logger.error("Error retrieving subjects", e);
        }
        return subjects;
    }

    @Override
    public List<Student> getStudentsBySubject(String subjectName) {
        List<Student> students = new ArrayList<>();
        String query = """
        SELECT s.id, s.rollNumber, s.name, s.dob, s.age
        FROM Students s
        JOIN StudentSubjects ss ON s.id = ss.studentId
        JOIN Subjects sub ON ss.subjectId = sub.id
        WHERE sub.subjectName = ?;
        """;
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, subjectName);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    students.add(new Student(
                            rs.getInt("id"),
                            rs.getInt("rollNumber"),
                            rs.getString("name"),
                            rs.getString("dob"),
                            rs.getInt("age")));
                }
            }
        } catch (SQLException e) {
            logger.error("Error retrieving students by subject name", e);
        }
        return students;
    }


    @Override
    public Student getStudentByRollNumber(int rollNumber) {
        Student student = null;
        String query = "SELECT * FROM Students WHERE rollNumber = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, rollNumber);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    student = new Student(
                            rs.getInt("id"),
                            rs.getInt("rollNumber"),
                            rs.getString("name"),
                            rs.getString("dob"),
                            rs.getInt("age"));
                }
            }
        } catch (SQLException e) {
            logger.error("Error retrieving student by roll number", e);
        }
        return student;
    }
    private int getOrAddSubject(String subjectName) throws SQLException {
        // Check if the subject exists
        PreparedStatement checkStmt = connection.prepareStatement(
                "SELECT id FROM Subjects WHERE subjectName = ?");
        checkStmt.setString(1, subjectName);
        ResultSet rs = checkStmt.executeQuery();

        if (rs.next()) {
            return rs.getInt("id"); // Return existing subject ID
        } else {
            // Add new subject
            PreparedStatement insertStmt = connection.prepareStatement(
                    "INSERT INTO Subjects (subjectName) VALUES (?)",
                    Statement.RETURN_GENERATED_KEYS);
            insertStmt.setString(1, subjectName);
            insertStmt.executeUpdate();

            ResultSet newRs = insertStmt.getGeneratedKeys();
            newRs.next();
            return newRs.getInt(1); // Return new subject ID
        }
    }

}
