package reg_241047037;

import java.util.List;

public interface Interface {
    void addStudent(Student student);
    void addSubject(Subject subject);
    List<Student> getAllStudents();
    List<Subject> getAllSubjects();
    List<Student> getStudentsBySubject(String subjectName);  // Change: Accept subjectName as a String
    Student getStudentByRollNumber(int rollNumber);
}
