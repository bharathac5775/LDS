package reg_241047037;

import java.util.List;  // Add this import statement
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Implementation implementation = new Implementation();
        java.util.Scanner scanner = new java.util.Scanner(System.in);

        while (true) {
            System.out.println("""
                    Menu:
                    1. Add Student
                    2. Add Subject
                    3. View Students
                    4. View Subjects
                    5. View Students by Subject
                    6. View Student by Roll Number
                    7. Exit
                    Enter your choice: """);
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1 -> {
                    System.out.println("Enter Roll Number: ");
                    int rollNumber = scanner.nextInt();
                    scanner.nextLine();
                    System.out.println("Enter Name: ");
                    String name = scanner.nextLine();
                    System.out.println("Enter DOB (yyyy-mm-dd): ");
                    String dob = scanner.nextLine();
                    System.out.println("Enter Age: ");
                    int age = scanner.nextInt();
                    scanner.nextLine();

                    implementation.addStudent(new Student(0, rollNumber, name, dob, age));
                }

                case 2 -> {
                    System.out.println("Enter Subject Name: ");
                    String subjectName = scanner.nextLine();
                    implementation.addSubject(new Subject(0, subjectName));
                }
                case 3 -> implementation.getAllStudents()
                        .forEach(System.out::println);
                case 4 -> implementation.getAllSubjects()
                        .forEach(System.out::println);
                case 5 -> {
                    System.out.println("Enter Subject Name: ");
                    String subjectName = scanner.nextLine();
                    List<Student> students = implementation.getStudentsBySubject(subjectName);
                    if (students.isEmpty()) {
                        System.out.println("No students found for subject: " + subjectName);
                    } else {
                        for (Student student : students) {
                            System.out.println(student);
                        }
                    }
                }

                case 6 -> {
                    System.out.println("Enter Roll Number: ");
                    int rollNumber = scanner.nextInt();
                    scanner.nextLine();
                    Student student = implementation.getStudentByRollNumber(rollNumber);
                    if (student != null) {
                        System.out.println(student);
                    } else {
                        System.out.println("Student not found.");
                    }
                }
                case 7 -> {
                    System.out.println("Exiting...");
                    return;
                }
                default -> System.out.println("Invalid choice. Try again.");
            }
        }
    }
}
