package reg_241047037;

public class Student {
    private int id;
    private int rollNumber;
    private String name;
    private String dob;
    private int age;

    public Student(int id, int rollNumber, String name, String dob, int age) {
        this.id = id;
        this.rollNumber = rollNumber; // Fixed initialization
        this.name = name;
        this.dob = dob;
        this.age = age;
    }

    public int getId() {
        return id;
    }

    public int getRollNumber() {
        return rollNumber;
    }

    public String getName() {
        return name;
    }

    public String getDob() {
        return dob;
    }

    public int getAge() {
        return age;
    }

    @Override
    public String toString() {
        return "Student{" +
                "id=" + id +
                ", rollNumber=" + rollNumber +
                ", name='" + name + '\'' +
                ", dob='" + dob + '\'' +
                ", age=" + age +
                '}';
    }
}
