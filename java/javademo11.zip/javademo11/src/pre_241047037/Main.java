package pre_241047037;
import java.util.Scanner;
public class Main {


    public static  void  main(String[] args){

        Scanner scanner = new Scanner(System.in);
        studentinterface s = new studentinterfaceImpl();

        while (true){

            System.out.println("""
                    menu:
                    1 add student
                    2 add subject
                    3 exit
                    
                    """);

               int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice){
                case 1 ->{
                    s.addstudent();

                }
                case 2 ->{
                    s.addsubject();
                }

                case 3 ->{
                    System.out.println("Exiting...");
                    return;
                }
            }
        }

    }


}
