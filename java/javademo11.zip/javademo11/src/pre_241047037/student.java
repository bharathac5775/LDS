package pre_241047037;

public class student {

    private int rollnumber;
    private int age;
    private String name;

    public int getRollnumber() {
        return rollnumber;
    }

    public int getAge() {
        return age;
    }

    public String getName() {
        return name;
    }
}
