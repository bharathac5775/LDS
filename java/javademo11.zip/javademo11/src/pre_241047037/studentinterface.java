package pre_241047037;

public interface studentinterface {

    public void addstudent();
    public void addsubject();

}
