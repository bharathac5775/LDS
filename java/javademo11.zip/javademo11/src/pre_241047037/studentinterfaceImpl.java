package pre_241047037;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class studentinterfaceImpl implements studentinterface {



    private Connection connection;

    public studentinterfaceImpl(){
        this.connection = dbconnection.getConnection();
        createtable();
    }





















    private  void createtable(){
        try(Statement stmt = connection.createStatement()){

            stmt.execute("IF DB_ID('pre_241047037') IS NULL CREATE DATABASE pre_241047037;");
            stmt.execute("USE pre_241047037;");
            stmt.execute("""
                    IF OBJECT_ID('Students1', 'U') IS NULL
                    CREATE TABLE Students1 (
                        id INT PRIMARY KEY IDENTITY(1,1),
                        rollNumber INT NOT NULL UNIQUE,
                        name NVARCHAR(100),
                        dob NVARCHAR(10),
                        age INT
                    );
                    """);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    
    @Override
    public void addstudent() {
        System.out.println("added");
    }

    @Override
    public void addsubject() {
        System.out.println("added");
    }
}
