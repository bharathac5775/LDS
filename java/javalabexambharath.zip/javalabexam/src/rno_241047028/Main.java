package rno_241047028;

import java.sql.Connection;
import java.util.Scanner;
import java.util.InputMismatchException;

public class Main {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        database db=new database();
        if(db.loaddbfile()){

            System.out.println("connection succes");
            productoperationimpl prodimpl=new productoperationimpl(db);
            while(true){
                System.out.println("1. Add Product");
                System.out.println("2. Update Product");
                System.out.println("3. Display Product");
                System.out.println("4. Exit");
                System.out.print("Enter your choice: ");

                int choice=scanner.nextInt();
                scanner.nextLine();

                switch (choice){

                    case 1:
                        System.out.println("Enter the product id");
                        String productID = scanner.nextLine();
                        System.out.println("Enter the product name");
                        String name = scanner.nextLine();
                        int quantity = getIntInput(scanner, "Enter product quantity: ");
                        double purprice = getDoubleInput(scanner, "Enter purchase price: ");
                        scanner.nextLine();
                        System.out.println("Enter the product category");
                        String category = scanner.nextLine(); // Now this will work
                        double mrp = getDoubleInput(scanner, "Enter mrp price: ");
                        scanner.nextLine();

                        product prod = new product(productID, name, quantity, purprice, category, mrp);
                        prodimpl.addproduct(prod);
                        break;


                    case 2:System.out.println("enter the product id to be updated");
                        String upproductID=scanner.nextLine();
                        System.out.println("Enter the product name which should be updated");
                        String upname=scanner.nextLine();
                        int upquantity = getIntInput(scanner, "Enter product quantity: ");

                        product upprod=new product(upproductID,upname,upquantity);
                        prodimpl.updateproduct(upprod);
                        break;
                    case 3:prodimpl.display();
                        break;
                    case 4:System.out.println("exiting...");
                        scanner.close();
                        return;
                    default:
                        System.out.println("Invalid choice. Please enter a valid option.");

                }
            }
        }
        else {
            System.out.println("not connected");
        }
    }
    private static int getIntInput(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                return scanner.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter an integer.");
                scanner.next();
            }
        }
    }

    private static int getIntInput(Scanner scanner) {
        return getIntInput(scanner, "");
    }

    private static double getDoubleInput(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                return scanner.nextDouble();
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a valid number.");
                scanner.next();
            }
        }
    }
}