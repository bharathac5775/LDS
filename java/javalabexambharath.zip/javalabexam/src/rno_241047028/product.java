package rno_241047028;

import java.sql.PreparedStatement;

public class product {
    private String productID;
    private String name;
    private int quentity;
    private double purcheseprice;
    private String category;
    private double mrp;

    public product(String productID,String name,int quentity,double purcheseprice,String category,double mrp){
        this.productID=productID;
        this.name=name;
        this.quentity=quentity;
        this.purcheseprice=purcheseprice;
        this.category=category;
        this.mrp=mrp;
    }

    public product(String upproductID, String upname, int upquantity) {
        this.productID=upproductID;
        this.name=upname;
        this.quentity=upquantity;
    }

    public String getProductID() {
        return productID;
    }

    public String getName() {
        return name;
    }

    public int getQuentity() {
        return quentity;
    }

    public double getPurcheseprice() {
        return purcheseprice;
    }

    public String getCategory() {
        return category;
    }

    public double getMrp() {
        return mrp;
    }
}
