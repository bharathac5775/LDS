package rno_241047028;

public interface productoperation {
    void addproduct(product prod);
    void updateproduct(product upprod);
    void display();
}
