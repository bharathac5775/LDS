package rno_241047028;

import java.sql.Connection;
import java.sql.*;

public class productoperationimpl implements productoperation {
    private final Connection connection;

    public productoperationimpl(database db) {
        this.connection = db.getConnection();
        createTableproduct();
    }

    private void createTableproduct() {
//
        String sql="IF NOT EXISTS(SELECT * FROM sysobjects WHERE name='product')"+
                "CREATE TABLE product("+
                "product_id VARCHAR(50) PRIMARY KEY,"+
                "name VARCHAR(100), " +
                "quantity INT, " +
                "purprice FLOAT, " +
                "category VARCHAR(100), " +
                "mrp FLOAT" +
                ")";



        try(Statement stmt=connection.createStatement()){
            stmt.execute(sql);
            System.out.println("product table created or already created");
        } catch (SQLException e) {
            System.out.println("error in creating table"+e.getMessage());
        }
    }

    public void addproduct(product prod){
        if(prod.getProductID()==null || prod.getProductID().trim().isEmpty()){
            System.out.println("product should not be null");
        }
        if(prod.getName()==null || prod.getName().trim().isEmpty()){
            System.out.println("product name should not be null");
        }
        if(prod.getQuentity()<=0){
            System.out.println("quentity should be positive");
        }

        if(prod.getPurcheseprice()<=0){
            System.out.println("enter positive value");
        }
        if(prod.getCategory()==null || prod.getCategory().trim().isEmpty()){
            System.out.println("product catogory should not be null");
        }
        if(prod.getMrp()<=0){
            System.out.println("enter positive value");
        }

        String insertsql = "INSERT INTO product (product_id, name, quantity, purprice, category, mrp) VALUES (?,?,?,?,?,?)";
        try (PreparedStatement pstmt = connection.prepareStatement(insertsql)) {
            pstmt.setString(1, prod.getProductID());
            pstmt.setString(2, prod.getName());
            pstmt.setInt(3, prod.getQuentity());
            pstmt.setDouble(4, prod.getPurcheseprice());
            pstmt.setString(5, prod.getCategory());
            pstmt.setDouble(6, prod.getMrp());

            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Product added successfully.");
            } else {
                System.out.println("Failed to add the product.");
            }
        } catch (SQLException e) {
            System.out.println("Error in adding product: " + e.getMessage());
        }
    }
    @Override
    public void updateproduct(product upprod) {
        if (upprod.getProductID() == null || upprod.getProductID().trim().isEmpty()) {
            System.out.println("Product ID should not be null or empty.");
            return;
        }

        String updatesql = "UPDATE product SET  quantity = quantity + ? WHERE product_id = ? AND name = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(updatesql)) {

            pstmt.setInt(1, upprod.getQuentity());
            pstmt.setString(2, upprod.getProductID());
            pstmt.setString(3, upprod.getName());

            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Product updated successfully.");
            } else {
                System.out.println("Product not found or no changes made.");
            }
        } catch (SQLException e) {
            System.out.println("Error in updating product: " + e.getMessage());
        }
    }
    @Override
    public void display() {
        String selectsql = "SELECT * FROM product";
        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(selectsql)) {
            if (!rs.isBeforeFirst()) { // Check if there are any rows
                System.out.println("No products in the database.");
                return;
            }

            System.out.println("Product List:");
            while (rs.next()) {
                String productID = rs.getString("product_id");
                String name = rs.getString("name");
                int quantity = rs.getInt("quantity");
                double purprice = rs.getDouble("purprice");
                String category = rs.getString("category");
                double mrp = rs.getDouble("mrp");

                System.out.println("Product ID: " + productID + ", Name: " + name + ", Quantity: " + quantity +
                        ", Purchase Price: " + purprice + ", Category: " + category + ", MRP: " + mrp);
            }
        } catch (SQLException e) {
            System.out.println("Error in displaying products: " + e.getMessage());
        }
    }
}



    
